package net.xdclass.enums;

public enum SendCodeEnum {

    /**
     * 用户注册
     */
    USER_REGISTER;

}
